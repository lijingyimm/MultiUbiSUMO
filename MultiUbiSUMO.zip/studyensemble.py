import os
import sys
import csv
import copy
import math
import random
import pandas as pd
import numpy as np
import keras.metrics
from keras.models import load_model
from keras.models import Model
from keras.layers import Dense
from keras.layers.merge import concatenate
from keras.callbacks import EarlyStopping
#from keras.utils import plot_model
from sklearn.metrics import roc_curve,auc,average_precision_score
from getData import get_data
# from getData import get_data_test
from DProcess import convertRawToXY
from submodel import OnehotNetwork,OtherNetwork,PhysicochemicalNetwork,HydrophobicityNetwork,CompositionNetwork,BetapropensityNetwork,AlphaturnpropensityNetwork
import json
import keras.utils.np_utils as kutils
import tensorflow as tf

# tf_config = tf.ConfigProto()
# tf_config.gpu_options.allow_growth = True
# tf.Session(config=tf_config)


def calculate_performance(test_num,labels,predict_y,predict_score):
    tp = [0,0,0]
    fp = [0,0,0]
    tn = [0,0,0]
    fn = [0,0,0]


    print('labels:',labels[0000:1000])     #标签
    print('predict_y:',predict_y[0000:1000])   #预测
    for i in range(test_num):
         index_r=labels[i]    #标签类别
         index_p=predict_y[i] #

         if (index_r == 0):
             if (index_r == index_p):
                 tp[0] += 1
             else:
                 fn[0] += 1
         else:
             if (0 == index_p):
                 fp[0] += 1
             else:
                 tn[0] += 1

         if (index_r == 1):
             if (index_r == index_p):
                 tp[1] += 1
             else:
                 fn[1] += 1
         else:
             if (1 == index_p):
                 fp[1] += 1
             else:
                 tn[1] += 1

         if (index_r == 2):
             if (index_r == index_p):
                 tp[2] += 1
             else:
                 fn[2] += 1
         else:
             if (2 == index_p):
                 fp[2] += 1
             else:
                 tn[2] += 1
         # if (index_r == 3):
         #     if (index_r == index_p):
         #         tp[3] += 1
         #     else:
         #        fn[3] += 1
         # else:
         #     if (3 == index_p):
         #         fp[3] += 1
         #     else:
         #         tn[3] += 1

    precision=[0,0,0]
    specificity=[0,0,0]
    sensitivity=[0,0,0]
    
    print('tp:',tp)
    print('tn:',tn)
    print('fp:',fp)
    print('fn:',fn)

    sum1=0.0
    sum2=0.0
    sum3=0.0
    kind=3
    
    i = 0
    strResults=str('')
    while (i<kind):
       # if((tp[i]+fn[i])==0 or (tp[i]+fp[i])==0 or (tn[i]+fp[i])==0):
       #      del precision[i]
       #      del sensitivity[i]
       #      del specificity[i]
       #      del tp[i]
       #      del tn[i]
       #      del fp[i]
       #      del fn[i]
       #      kind-=1
       #      i-=1
       # else:
        precision[i]=tp[i]/(tp[i]+fp[i]+sys.float_info.epsilon)
        sensitivity[i]=tp[i]/(tp[i]+fn[i]+sys.float_info.epsilon)
        specificity[i]=tn[i]/(tn[i]+fp[i]+sys.float_info.epsilon)
        # if(i==0):
        #     strResults='tp'+ str(i) +' '+ str(tp[i]) + ' tn' + str(i) +' '+  str(tn[i]) + 'fp' + str(i) + ' ' +str(fp[i])+ 'fn' + str(i) + ' ' +str(fn[i])+'\n'
        #     strResults=strResults +' precision' + str(i) +' '+ str(precision[i]) + ' sensitivity' + str(i) +' '+  str(sensitivity[i]) + 'specificity' + str(i) + ' ' +str(specificity[i])+'\n'
        #     sum1+=precision[i]
        #     sum2+=specificity[i]
        #     sum3+=sensitivity[i]
        # else:

        strResults= strResults+'tp'+ str(i) +' '+ str(tp[i]) + '\ttn' + str(i) +' '+  str(tn[i]) + '\tfp' + str(i) + ' ' +str(fp[i])+ '\tfn' + str(i) + ' ' +str(fn[i])+'\n'
        strResults= strResults +'precision' + str(i) +' '+ str(precision[i]) + '\tsensitivity' + str(i) +' '+  str(sensitivity[i]) + '\tspecificity' + str(i) + ' ' + str(specificity[i])+'\n'
        sum1+=precision[i]
        sum2+=specificity[i]
        sum3+=sensitivity[i]
        i+=1

    print('precision')
    print(precision)
    print('sensitivity')
    print(sensitivity)
    print('specificity')
    print(specificity)
    print('mean precision')
    print(sum1/kind)
    print('mean specificity')
    print(sum2 / kind)
    print('mean sensitivity')
    print(sum3 / kind)

    strResults =strResults+ 'mean_precision ' + str(sum1/kind) + '\tmean_sensitivity ' + str(sum3/kind) + '\tmean_specificity' + str(sum2/kind)+'\n'
    return strResults


def normalization(array):

	normal_array = []
	de = array.sum()
	for i in array:
		normal_array.append(float(i)/de)

	return normal_array

'''
def normalization2(array):

	normal_array = []
	de = 1
	for i in array:
		de *= i
	print(de)
	for i in array:
		nu = i
		print(nu)
		normal_array.append(math.log(nu,de))

	return normal_array
'''
def normalization_softmax(array):

	normal_array = []
	de = 0
	for i in array:
		de += math.exp(i)
	for i in array:
		normal_array.append(math.exp(i)/de)

	return normal_array

def predict_stacked_model(model,test_oneofkeyX,test_physicalXo,test_physicalXp,test_physicalXh,test_physicalXc,test_physicalXb,test_physicalXa):

	testX = [test_oneofkeyX,test_physicalXo,test_physicalXp,test_physicalXh,test_physicalXc,test_physicalXb,test_physicalXa]

	return model.predict(testX,verbose=1)

def fit_stacked_model(model,val_oneofkeyX,val_physicalXo,val_physicalXp,val_physicalXh,val_physicalXc,val_physicalXb,val_physicalXa,valY):

	valX = [val_oneofkeyX,val_physicalXo,val_physicalXp,val_physicalXh,val_physicalXc,val_physicalXb,val_physicalXa]
	early_stopping = EarlyStopping(monitor='val_loss',mode='min',patience=5)

	model.fit(valX, valY, epochs=15,callbacks=[early_stopping],class_weight='auto',batch_size=4096,verbose=1,validation_split=0.2)

def define_stacked_model(members):
	# update all layers in all models to not be trainable
	for i in range(len(members)):
		model = members[i]
		for layer in model.layers:
			# make not trainable
			layer.trainable = False
			# rename to avoid 'unique layer name' issue
			layer.name = 'ensemble_' + str(i+1) + '_' + layer.name
	# define multi-headed input
	ensemble_visible = [model.input for model in members]
	# concatenate merge output from each model
	ensemble_outputs = [model.output for model in members]  ##### ensemble_outputs (len7) <class 'list'> model.output <class 'tensorflow.python.framework.ops.Tensor'>
	merge = concatenate(ensemble_outputs) ##### <class 'tensorflow.python.framework.ops.Tensor'>
	hidden = Dense(7, activation='relu')(merge)
	output = Dense(3, activation='softmax')(hidden)
	model = Model(inputs=ensemble_visible, outputs=output)
	#plot graph of ensemble
	#plot_model(model, show_shapes=True, to_file='model_graph.png')
	print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
	model.compile(loss='categorical_crossentropy', optimizer='Nadam', metrics=[keras.metrics.categorical_accuracy])

	return model

def load_all_models(n_models,iteration_times):

	all_models = list()
	for i in range(n_models):
		if(i==0):
			filename = 'model/'+str(iteration_times)+'model/OnehotNetwork.h5'
		elif(i==1):
			filename = 'model/'+str(iteration_times)+'model/OtherNetwork.h5'
		elif(i==2):
			filename = 'model/'+str(iteration_times)+'model/PhysicochemicalNetwork.h5'
		elif(i==3):
			filename = 'model/'+str(iteration_times)+'model/HydrophobicityNetwork.h5'
		elif(i==4):
			filename = 'model/'+str(iteration_times)+'model/CompositionNetwork.h5'
		elif(i==5):
			filename = 'model/'+str(iteration_times)+'model/BetapropensityNetwork.h5'
		elif(i==6):
			filename = 'model/'+str(iteration_times)+'model/AlphaturnpropensityNetwork.h5'
		# load model from file
		model = load_model(filename)
		# add to list of members
		all_models.append(model)
		print('>loaded %s' % filename)

	return all_models

def NewshufflePosNeg(data2):

	data2_over=[]
	index = [i for i in range(len(data2))]
	random.shuffle(index)

	data2_over = data2.as_matrix()[index]
	data2_over = pd.DataFrame(data2_over)

	return data2_over

def Newshufflewrr(data1_0,data1_1,data1_2):
	##### Create an index with nummber of posnum #####
	index = [i for i in range(len(data1_0))]
	random.shuffle(index)
	data1_0 = pd.DataFrame(data1_0)
	data1_0 = data1_0.as_matrix()[index]
	data1_0_ss = pd.DataFrame(data1_0)

	index = [i for i in range(len(data1_1))]
	random.shuffle(index)
	data1_1 = pd.DataFrame(data1_1)
	data1_1 = data1_1.as_matrix()[index]
	data1_1_ss = pd.DataFrame(data1_1)

	index = [i for i in range(len(data1_2))]
	random.shuffle(index)
	data1_2 = pd.DataFrame(data1_2)
	data1_2 = data1_2.as_matrix()[index]
	data1_2_ss = pd.DataFrame(data1_2)
	return data1_0_ss, data1_1_ss, data1_2_ss

def get_matrix(windows_0,windows_1,windows_2):
	windows_0 = pd.DataFrame(windows_0)
	windows_1 = pd.DataFrame(windows_1)
	windows_2 = pd.DataFrame(windows_2)
	windows_all = pd.concat([windows_0,windows_1,windows_2])
	windows_all = windows_all.as_matrix()
	del windows_0,windows_1,windows_2
	return windows_all
	
val_windows_0, val_windows_1,val_windows_2 = get_data(r'data/multidata/8val.txt',r'data/pssmpickle2/', label=True)
all_train_windows_0, all_train_windows_1,all_train_windows_2 = get_data(r'data/multidata/8realtrain.txt',r'data/pssmpickle2/', label=True)
test_windows_0, test_windows_1,test_windows_2 = get_data(r'data/multidata/8test.txt',r'data/pssmpickle2/', label=True)


ff = int(len(test_windows_2))  #Fractional factor
test_windows_0 = test_windows_0[0:ff]
ff = int(len(test_windows_2))
test_windows_1 = test_windows_1[0:ff]
ff = int(len(test_windows_2))
test_windows_2 = test_windows_2[0:ff]
test_windows_all = get_matrix(test_windows_0, test_windows_1, test_windows_2)

test_oneofkeyX, testY = convertRawToXY(test_windows_all,codingMode=0)
test_oneofkeyX.shape = (test_oneofkeyX.shape[0],test_oneofkeyX.shape[2],test_oneofkeyX.shape[3])
test_physicalXo, _ = convertRawToXY(test_windows_all,codingMode=9)
test_physicalXo.shape = (test_physicalXo.shape[0],test_physicalXo.shape[2],test_physicalXo.shape[3])
test_physicalXp, _ = convertRawToXY(test_windows_all,codingMode=10)
test_physicalXp.shape = (test_physicalXp.shape[0],test_physicalXp.shape[2],test_physicalXp.shape[3])
test_physicalXh, _ = convertRawToXY(test_windows_all,codingMode=11)
test_physicalXh.shape = (test_physicalXh.shape[0],test_physicalXh.shape[2],test_physicalXh.shape[3])
test_physicalXc, _ = convertRawToXY(test_windows_all,codingMode=12)
test_physicalXc.shape = (test_physicalXc.shape[0],test_physicalXc.shape[2],test_physicalXc.shape[3])
test_physicalXb, _ = convertRawToXY(test_windows_all,codingMode=13)
test_physicalXb.shape = (test_physicalXb.shape[0],test_physicalXb.shape[2],test_physicalXb.shape[3])
test_physicalXa, _ = convertRawToXY(test_windows_all,codingMode=14)
test_physicalXa.shape = (test_physicalXa.shape[0],test_physicalXa.shape[2],test_physicalXa.shape[3])
# del test_windows_0, test_windows_1, test_windows_2,test_windows_all
# print(test_oneofkeyX)
# print(test_oneofkeyX.shape)
# print(test_oneofkeyX.value)
# data = pd.DataFrame(test_oneofkeyX)
# writer = pd.ExcelWriter('result/test.xlsx')		# 写入Excel文件
# data.to_excel(writer, 'page_1', float_format='%.5f')		# ‘page_1’是写入excel的sheet名
# writer.save()
# writer.close()
print("Test data coding finished!")


ff = int(len(val_windows_2))  #Fractional factor
val_windows_0 = val_windows_0[0:ff]
ff = int(len(val_windows_2))
val_windows_1 = val_windows_1[0:ff]
ff = int(len(val_windows_2))
val_windows_2 = val_windows_2[0:ff]
val_windows_all = get_matrix(val_windows_0, val_windows_1,val_windows_2)

val_oneofkeyX,valY = convertRawToXY(val_windows_all,codingMode=0)
val_oneofkeyX.shape = (val_oneofkeyX.shape[0],val_oneofkeyX.shape[2],val_oneofkeyX.shape[3])
val_physicalXo,_ = convertRawToXY(val_windows_all,codingMode=9)
val_physicalXo.shape = (val_physicalXo.shape[0],val_physicalXo.shape[2],val_physicalXo.shape[3])
val_physicalXp,_ = convertRawToXY(val_windows_all,codingMode=10)
val_physicalXp.shape = (val_physicalXp.shape[0],val_physicalXp.shape[2],val_physicalXp.shape[3])
val_physicalXh,_ = convertRawToXY(val_windows_all,codingMode=11)
val_physicalXh.shape = (val_physicalXh.shape[0],val_physicalXh.shape[2],val_physicalXh.shape[3])
val_physicalXc,_ = convertRawToXY(val_windows_all,codingMode=12)
val_physicalXc.shape = (val_physicalXc.shape[0],val_physicalXc.shape[2],val_physicalXc.shape[3])
val_physicalXb,_ = convertRawToXY(val_windows_all,codingMode=13)
val_physicalXb.shape = (val_physicalXb.shape[0],val_physicalXb.shape[2],val_physicalXb.shape[3])
val_physicalXa,_ = convertRawToXY(val_windows_all,codingMode=14)
val_physicalXa.shape = (val_physicalXa.shape[0],val_physicalXa.shape[2],val_physicalXa.shape[3])
del val_windows_0, val_windows_1,val_windows_2,val_windows_all
print("Val data coding finished!")

iteration_times = 30
for t in range(0,iteration_times):
	print("iteration_times: %d"%t)
	train_windows_0, train_windows_1,train_windows_2 = Newshufflewrr(all_train_windows_0, all_train_windows_1,all_train_windows_2)
	ff = int(len(train_windows_2))  #Fractional factor
	train_windows_0 = train_windows_0[0:ff]
	ff = int(len(train_windows_2))
	train_windows_1 = train_windows_1[0:ff]
	ff = int(len(train_windows_2))
	train_windows_2 = train_windows_2[0:ff]
	print("train_0_num: %d"%len(train_windows_0))
	print("train_1_num: %d"%len(train_windows_1))
	print("train_2_num: %d"%len(train_windows_2))


	train_windows_all = pd.concat([train_windows_0, train_windows_1,train_windows_2])
	train_windows_all = NewshufflePosNeg(train_windows_all)
	train_windows_all = pd.DataFrame(train_windows_all)
	matrix_train_windows_all = train_windows_all.as_matrix()

	train_oneofkeyX,trainY = convertRawToXY(matrix_train_windows_all,codingMode=0)
	train_oneofkeyX.shape = (train_oneofkeyX.shape[0],train_oneofkeyX.shape[2],train_oneofkeyX.shape[3])
	train_physicalXo,_ = convertRawToXY(matrix_train_windows_all,codingMode=9)
	train_physicalXo.shape = (train_physicalXo.shape[0],train_physicalXo.shape[2],train_physicalXo.shape[3])
	train_physicalXp,_ = convertRawToXY(matrix_train_windows_all,codingMode=10)
	train_physicalXp.shape = (train_physicalXp.shape[0],train_physicalXp.shape[2],train_physicalXp.shape[3])
	train_physicalXh,_ = convertRawToXY(matrix_train_windows_all,codingMode=11)
	train_physicalXh.shape = (train_physicalXh.shape[0],train_physicalXh.shape[2],train_physicalXh.shape[3])
	train_physicalXc,_ = convertRawToXY(matrix_train_windows_all,codingMode=12)
	train_physicalXc.shape = (train_physicalXc.shape[0],train_physicalXc.shape[2],train_physicalXc.shape[3])
	train_physicalXb,_ = convertRawToXY(matrix_train_windows_all,codingMode=13)
	train_physicalXb.shape = (train_physicalXb.shape[0],train_physicalXb.shape[2],train_physicalXb.shape[3])
	train_physicalXa,_ = convertRawToXY(matrix_train_windows_all,codingMode=14)
	train_physicalXa.shape = (train_physicalXa.shape[0],train_physicalXa.shape[2],train_physicalXa.shape[3])
	print("itreation %d times Train data coding finished!" %t)

	if(t==0):
		struct_Onehot_model = OnehotNetwork(train_oneofkeyX,trainY,val_oneofkeyX,valY,train_time=t)
		physical_O_model = OtherNetwork(train_physicalXo,trainY,val_physicalXo,valY,train_time=t)
		physical_P_model = PhysicochemicalNetwork(train_physicalXp,trainY,val_physicalXp,valY,train_time=t)
		physical_H_model = HydrophobicityNetwork(train_physicalXh,trainY,val_physicalXh,valY,train_time=t)
		physical_C_model = CompositionNetwork(train_physicalXc,trainY,val_physicalXc,valY,train_time=t)
		physical_B_model = BetapropensityNetwork(train_physicalXb,trainY,val_physicalXb,valY,train_time=t)
		physical_A_model = AlphaturnpropensityNetwork(train_physicalXa,trainY,val_physicalXa,valY,train_time=t)
		print("itreation %d times training finished!" %t)
	else:
		struct_Onehot_model = OnehotNetwork(train_oneofkeyX,trainY,val_oneofkeyX,valY,train_time=t,compilemodels=struct_Onehot_model)

		physical_O_model = OtherNetwork(train_physicalXo,trainY,val_physicalXo,valY,train_time=t,compilemodels=physical_O_model)
		physical_P_model = PhysicochemicalNetwork(train_physicalXp,trainY,val_physicalXp,valY,train_time=t,compilemodels=physical_P_model)
		physical_H_model = HydrophobicityNetwork(train_physicalXh,trainY,val_physicalXh,valY,train_time=t,compilemodels=physical_H_model)
		physical_C_model = CompositionNetwork(train_physicalXc,trainY,val_physicalXc,valY,train_time=t,compilemodels=physical_C_model)
		physical_B_model = BetapropensityNetwork(train_physicalXb,trainY,val_physicalXb,valY,train_time=t,compilemodels=physical_B_model)
		physical_A_model = AlphaturnpropensityNetwork(train_physicalXa,trainY,val_physicalXa,valY,train_time=t,compilemodels=physical_A_model)
		print("itreation %d times training finished!" %t)


	monitor = 'val_loss'
	weights = []
	with open ('model/loss/'+str(t)+'onehotloss.json', 'r') as checkpoint_fp:
		weights.append(1/float(json.load(checkpoint_fp)[monitor]))
	with open ('model/loss/'+str(t)+'Onetloss.json', 'r') as checkpoint_fp:
		weights.append(1/float(json.load(checkpoint_fp)[monitor]))
	with open ('model/loss/'+str(t)+'Pnetloss.json', 'r') as checkpoint_fp:
		weights.append(1/float(json.load(checkpoint_fp)[monitor]))
	with open ('model/loss/'+str(t)+'Hnetloss.json', 'r') as checkpoint_fp:
		weights.append(1/float(json.load(checkpoint_fp)[monitor]))
	with open ('model/loss/'+str(t)+'Cnetloss.json', 'r') as checkpoint_fp:
		weights.append(1/float(json.load(checkpoint_fp)[monitor]))
	with open ('model/loss/'+str(t)+'Bnetloss.json', 'r') as checkpoint_fp:
		weights.append(1/float(json.load(checkpoint_fp)[monitor]))
	with open ('model/loss/'+str(t)+'Anetloss.json', 'r') as checkpoint_fp:
		weights.append(1/float(json.load(checkpoint_fp)[monitor]))

	weight_array = np.array(weights, dtype= np.float)
	del weights

	#normalize checkpoit data as weights
	weight_array = normalization(weight_array)

	# data = pd.DataFrame(weight_array)
	# writer = pd.ExcelWriter('result/weight_array.xlsx')		# 写入Excel文件
	# data.to_excel(writer, 'page_1', float_format='%.5f')		# ‘page_1’是写入excel的sheet名
	# writer.save()
	# writer.close()
	# print('write weight*****************************')

	#weight_array = normalization_softmax(weight_array)

	predict_weighted_merge = 0
	#load model weights and checkpoint file
	predict_temp = weight_array[0] * struct_Onehot_model.predict(test_oneofkeyX)
	predict_weighted_merge += predict_temp

	data = pd.DataFrame(predict_weighted_merge)
	writer = pd.ExcelWriter('result/input.xlsx')		# 写入Excel文件
	data.to_excel(writer, 'page_1', float_format='%.5f')		# ‘page_1’是写入excel的sheet名
	writer.save()
	writer.close()
	print('write input*****************************')


	
	predict_temp = weight_array[1] * physical_O_model.predict(test_physicalXo)
	predict_weighted_merge += predict_temp

	predict_temp = weight_array[2] * physical_P_model.predict(test_physicalXp)
	predict_weighted_merge += predict_temp

	predict_temp = weight_array[3] * physical_H_model.predict(test_physicalXh)
	predict_weighted_merge += predict_temp

	predict_temp = weight_array[4] * physical_C_model.predict(test_physicalXc)
	predict_weighted_merge += predict_temp

	predict_temp = weight_array[5] * physical_B_model.predict(test_physicalXb)
	predict_weighted_merge += predict_temp

	predict_temp = weight_array[6] * physical_A_model.predict(test_physicalXa)
	predict_weighted_merge += predict_temp


	print('predict_weighted_merge',predict_weighted_merge)
	score = predict_weighted_merge
	data = pd.DataFrame(score)
	writer = pd.ExcelWriter('result/output.xlsx')		# 写入Excel文件
	data.to_excel(writer, 'page_1', float_format='%.5f')		# ‘page_1’是写入excel的sheet名
	writer.save()
	writer.close()
	print('write output*****************************')

	# ids = copy.deepcopy(predict_weighted_merge[:,1])

	ids = np.argmax(predict_weighted_merge, axis=1)   #predict_y 每行中最大值所在列

	for i in range(len(predict_weighted_merge)):
		if (predict_weighted_merge[i][1]>=0.18 and predict_weighted_merge[i][0]<=0.5):
			ids[i] = 1.0
			continue
		else:
			ids[i] = 0.0


		if (predict_weighted_merge[i][2]>=0.40 and predict_weighted_merge[i][0]<=0.5):
			ids[i] = 2.0
		else:
			ids[i] = 0.0





	max = np.amax(predict_weighted_merge, axis=1)

	print('ids_predict', ids[0000:1000])  #预测类别
	print('max', max[0000:1000])  #最高分数
	# class1=0
	# for i in ids:
	# 	if(i==1):
	# 		class1+=1
	# 		print('num of class:',class1)
	print('testY_label',testY[0000:1000])  
	test_Y=testY.argmax(axis=1)    #label
	print('test_Y_label',test_Y[0000:1000])
    
	with open('result/9new.txt', mode='a') as resFile:
		resFile.write(str(t)+" "+calculate_performance(len(test_Y),test_Y,ids,max)+'\r\n')
	resFile.close()
	true_label = test_Y

	result = np.column_stack((true_label,ids,score))
	result = pd.DataFrame(result)
	result.to_csv(path_or_buf='result/result'+'-'+str(t)+'.txt',index=False,header=None,sep='\t',quoting=csv.QUOTE_NONE)



